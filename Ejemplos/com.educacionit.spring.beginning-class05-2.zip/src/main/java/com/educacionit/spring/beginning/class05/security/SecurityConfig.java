package com.educacionit.spring.beginning.class05.security;


import com.educacionit.spring.beginning.class05.dao.AppUserDetailsServiceDAO;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;


@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	@Override
	public void configure(AuthenticationManagerBuilder auth)
			throws Exception {


        auth.inMemoryAuthentication().withUser("educacionit").password("1234").roles("USER");

        auth.userDetailsService(new AppUserDetailsServiceDAO());
	}
	
	@Override
    public void configure(WebSecurity web) throws Exception {
        web
            .ignoring()
                .antMatchers("/*.html");
    }
}