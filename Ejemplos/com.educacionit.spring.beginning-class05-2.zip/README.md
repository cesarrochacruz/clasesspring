# com.educacionit.spring.beginning-class05-2
Java Education Project for learn Springframework.



## Introducción
Este demo esta constituido por una aplicacion, llamada "com.educacionit.spring.beginning-class05-2" la cual se encarga de
mostrar un simple mensaje en la pagina web de saludo. Este ejemplo representa:

1. El uso de spring MVC.
2. Configuracion de spring MVC.
3. El uso de spring Security


## Requerimientos
1. Maven
2. Cualquier IDE de desarrollo con soporte Java y Maven.
3. Apache Tomcat (http://tomcat.apache.org/)



Ejercicios (Básicos/Intermedio)
==========

La configuración de este proyecto es independiente de cualquier IDE de desarrollo, debido a que el proyecto
fue creado utilizando maven. (http://maven.apache.org)

Así que son libres de utilizar el IDE con el cual se sientan más agusto.


Referencias
===========

1. http://maven.apache.org/
2. http://tomcat.apache.org/
2. https://projects.spring.io/spring-framework/