package com.educacionit.spring.beginning.class04;


import org.springframework.beans.factory.annotation.Autowired;


public class UserDaoImpl implements UserDao {

    public void register(User user) {

    }
    public User validateUser(Login login) {
        return null;
    }
}
