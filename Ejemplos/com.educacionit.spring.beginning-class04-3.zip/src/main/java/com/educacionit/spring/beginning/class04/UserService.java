package com.educacionit.spring.beginning.class04;


public class UserService implements IUserService {

    public void register(User user) {

    }
    public User validateUser(Login login) {
        return null;
    }
}
