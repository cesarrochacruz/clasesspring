package com.educacionit.spring.beginning.class04;

public interface IUserService {

    void register (User user);
    User validateUser( Login login);
}
