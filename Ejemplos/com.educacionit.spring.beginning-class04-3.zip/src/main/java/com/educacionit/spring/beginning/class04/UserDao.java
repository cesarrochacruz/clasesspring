package com.educacionit.spring.beginning.class04;

public interface UserDao {

    void register (User user);
    User validateUser( Login login);
}
