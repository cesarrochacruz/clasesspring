

package com.educacionit.java.spring.mongodb.rest.test;


// Packages and classes to import of jdk 1.8
import java.lang.reflect.Type;
import java.util.List;
import java.util.Map;

// Packages and classes to import of slf4j api.
import com.educacionit.java.spring.mongodb.rest.ServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// Packages and classes to import of gson api.
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

// Packages and classes to import of springframework 4.x
import org.springframework.http.*;

// Packages and classes to import of apache commons.
import static org.apache.commons.lang3.StringUtils.isEmpty;

// Packages and classes to import of spring boot 1.5.x
import org.springframework.boot.test.web.client.TestRestTemplate;

// Packages and classes to import of jackson api.
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

// Packages and classes to import of this project.




public abstract class AbstractRestApiIntegrationTest {


    // Protected instance fields declarations.
    // Rest client.
    protected TestRestTemplate restTemplate = new TestRestTemplate ();


    // Protected class fields declarations.
    // Server.
    protected final String SERVER = "http://localhost:";


    // Private class fields declarations.
    // Logger object.
    private final Logger logger = LoggerFactory.getLogger (AbstractRestApiIntegrationTest.class);


    // Public constructor declarations.
    /**
     *
     *  <p>Unique constructor without arguments.
     * */
    public AbstractRestApiIntegrationTest () {

        // Call to super class.
        super ();
    }


    // Protected instance method declarations.
    /**
     *
     *  <p>Method that build the string json response to object array.
     *
     *  @param src Source
     *  @return Array object.
     * */
    protected List<Map<String, Object>> buildObjects (String src) {

        logger.info ("Building objects...");
        List<Map<String, Object>> list;

        if (isEmpty (src)) {

            String m = "src is required...";
            logger.error (m);
            throw new com.educacionit.java.spring.mongodb.rest.ServiceException (m);
        }

        try {

            logger.debug ("Building objects...");
            Gson gson = new Gson();
            Type typeOfList = new TypeToken<List<Map<String, Object>>>() {}.getType();
            list = gson.fromJson (src, typeOfList);
            logger.debug ("Objects made...");

        } catch (Exception e) {
        /*
         * Catch the problems.
         * */
            String m = String.format ("Problems building objects %s", src);
            logger.error (m);
            throw new ServiceException(m, e);
        }

        // Return the value.
        logger.info ("Building process finished...");
        return list;
    }

    /**
     *
     *  <p>Method that set the initial values for execute the test.
     *
     *  @param url Endpoint.
     *  @param user User.
     *  @param pw password.
     *  @return Http headers.
     * */
    protected HttpHeaders getApiKey (String url, String user, String pw) {

        logger.info ("Executing the authentication process...");
        if (isEmpty (url) || isEmpty (user) || isEmpty (pw)) {

            String m = "url, user and pw are required...";
            logger.error (m);
            throw new ServiceException (m);
        }

        HttpHeaders headersResult = new HttpHeaders ();
        try {

            /*
             * Response from rest. (Auth)
             */
            logger.debug ("Setting request headers for auth process...");
            ObjectMapper mapper = new ObjectMapper ();
            Map<String, String> map;

            /*
             * Set headers.
             */
            HttpHeaders headers = new HttpHeaders ();
            headers.setContentType (MediaType.APPLICATION_JSON);

            logger.debug (String.format ("Executing POST request to %s Endpoint with %s and %s", url, user, pw));
            HttpEntity<String> entity = new HttpEntity<String>(String.format ("{\"username\":\"%s\",\"password\":\"%s\"}", user, pw), headers);
            ResponseEntity<String> response = restTemplate.postForEntity (url, entity, String.class);

            logger.debug (String.format ("Response from %s Endpoint with %s and %s", url, user, pw));
            String r = response.getBody();
            map = mapper.readValue (r, new TypeReference<Map<String, String>>(){});

            /*
             * Build the headers with api key.
             * */
            logger.debug (String.format ("Adding X-Auth-Token header with value %s", map.get ("token")));
            headersResult.setContentType (MediaType.APPLICATION_JSON);
            headersResult.set ("X-Auth-Token", map.get ("token"));

        } catch (Exception e) {
        /*
         * Catch the problems.
         * */
            String m = String.format ("Problems executing authentication to %s Endpoint with %s and %s", url, user, pw);
            logger.error (m);
            throw new ServiceException(m, e);
        }

        // Return the value.
        logger.info ("Authentication process finished...");
        return headersResult;
    }
}