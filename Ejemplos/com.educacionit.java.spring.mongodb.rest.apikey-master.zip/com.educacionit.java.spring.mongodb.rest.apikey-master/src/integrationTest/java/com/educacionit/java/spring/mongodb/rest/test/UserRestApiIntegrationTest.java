/*
 * @(#UserRestApiIntegrationTest.java 12/28/2017
 * Copyright 2017 Furszy, Inc. All rights reserved.
 * FURSZY/CONFIDENTIAL
 * */

package com.educacionit.java.spring.mongodb.rest.test;


// Packages and classes to import of jdk 1.8
import java.util.List;
import java.util.Map;

// Packages and classes to import of junit api.
import com.educacionit.java.spring.mongodb.rest.Application;
import com.educacionit.java.spring.mongodb.rest.domain.entity.UserEntity;
import com.educacionit.java.spring.mongodb.rest.repository.mongodb.IUserRepository;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

// Packages and classes to import of slf4j api.
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// Packages and classes to import of springframework 4.x
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

// Packages and classes to import of spring boot 1.5.x
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;

// Packages and classes to import of apache commons.
import static org.apache.commons.lang3.RandomStringUtils.randomAlphanumeric;

// Packages and classes to import of this project.


/**
 *
 *  <p>The class <code>com.furszy.rest.api.test.UserRestApiIntegrationTest</code> is a spring boot integration test.
 *
 *  <p>This class is <code>powered by springframework</code>
 *
 *
 *  @author  Raul Geomar Pena (raul.pena@gmail.com)
 *  @version 1.0.0
 *  @since   jdk 1.8
 *  @since   12/28/2017
 *  @see     RunWith
 *  @see     SpringBootTest
 * */
@RunWith (SpringJUnit4ClassRunner.class)
@SpringBootTest (classes = {Application.class}, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class UserRestApiIntegrationTest extends AbstractRestApiIntegrationTest {


    // Private instance fields declarations.
    // Port server.
    @LocalServerPort
    private int port;

    // Environment object.
    @Autowired
    private Environment env;

    // Transaction repository.
    @Autowired
    private IUserRepository repository = null;

    // Private class fields declarations.
    // Logger object.
    private final Logger logger = LoggerFactory.getLogger (UserRestApiIntegrationTest.class);


    // Public instance method declarations.
    /**
     *
     *  <p>Method that set the initial values for execute the test.
     *
     *  @see Before
     * */
    @Before
    public void setup () {

        // Test data.
        logger.debug ("Creating test users...");
        UserEntity p1 = new UserEntity ();
        p1.setUserName ("TEST-" + randomAlphanumeric (10));
        this.repository.save (p1);

        UserEntity p2 = new UserEntity ();
        p1.setUserName ("TEST-" + randomAlphanumeric (10));
        this.repository.save (p2);

        UserEntity p3 = new UserEntity ();
        p1.setUserName ("TEST-" + randomAlphanumeric (10));
        this.repository.save (p3);
    }

    /**
     *
     *  <p>Method that test find all users. (OK)
     *
     *  @see Test
     * */
    @Test
    public void findAll () {

        logger.info ("Starting Test...");
        String auth = SERVER.concat (String.valueOf (this.port)).concat ("/api/auth");
        String  url = SERVER.concat (String.valueOf (this.port)).concat ("/api/security/user");

        try {

            // Get credentials.
            logger.debug ("Getting credentials...");
            HttpHeaders headersSecurity = this.getApiKey (auth, env.getRequiredProperty ("rest.us"), env.getRequiredProperty("rest.pw"));

            // Execute the query.
            logger.debug (String.format ("Executing GET request to %s Endpoint with %s and %s", url, env.getRequiredProperty ("rest.us"), env.getRequiredProperty ("rest.pw")));
            HttpEntity<String> entity = new HttpEntity<>(null, headersSecurity);
            ResponseEntity<String> response = restTemplate.exchange (url, HttpMethod.GET, entity, String.class);

            // Check response.
            assertTrue (String.format ("Response GET from %s Endpoint with %s and %s", url,
                                        env.getRequiredProperty ("rest.us"),
                                        env.getRequiredProperty ("rest.pw")),
                                        response.getStatusCode().is2xxSuccessful ());

            String r = response.getBody ();
            logger.debug (String.format ("Response from %s Endpoint with %s and %s is %s", url, env.getRequiredProperty ("rest.us"), env.getRequiredProperty ("rest.pw"), r));

            List<Map<String, Object>> result =  buildObjects (r);
            assertNotNull (String.format ("Response from %s Endpoint with %s and %s are null", url, env.getRequiredProperty ("rest.us"), env.getRequiredProperty ("rest.pw")), result);
            assertTrue (String.format ("Response from %s Endpoint with %s and %s are empty", url, env.getRequiredProperty ("rest.us"), env.getRequiredProperty ("rest.pw")), result.size () > 0);
            assertTrue ("There aren't users", result.get (0).containsKey ("id"));

        } catch (Exception e) {
        /*
         * Catch teh problems.
         * */
            String m = String.format ("Problems with response from %s Endpoint with %s and %s", url, env.getRequiredProperty ("rest.us"), env.getRequiredProperty ("rest.pw"));
            logger.error (m);
            assertNotNull (m, e);
        }
    }

    /**
     *
     *  <p>Method that delete all resources used for this test.
     *
     *  @see After
     * */
    @After
    public void destroy () {

        // Test data.
        logger.debug ("Deleting test documents created...");
        this.repository.findByUserNameLike ("TEST-*").forEach ( e -> repository.delete (e));
    }
}