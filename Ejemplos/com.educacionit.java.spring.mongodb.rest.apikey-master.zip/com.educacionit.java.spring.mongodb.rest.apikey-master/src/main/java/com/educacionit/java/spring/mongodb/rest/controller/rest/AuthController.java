

package com.educacionit.java.spring.mongodb.rest.controller.rest;


import javax.servlet.http.HttpServletRequest;

import com.educacionit.java.spring.mongodb.rest.model.json.request.AuthenticationRequest;
import com.educacionit.java.spring.mongodb.rest.model.json.response.AuthenticationResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import org.springframework.mobile.device.Device;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.educacionit.java.spring.mongodb.rest.security.TokenUtils;
import com.educacionit.java.spring.mongodb.rest.service.ISecurityService;


@RestController
@RequestMapping ("${app.route.authentication}")
public class AuthController {



    @Value("${api.security.token.header}")
    private String tokenHeader;

    private AuthenticationManager authenticationManager;

    private TokenUtils tokenUtils;

    private UserDetailsService userDetailsService;

    private ISecurityService securityService;


	private static final Logger logger = LoggerFactory.getLogger (AuthController.class);


 	public AuthController () {

 		super ();
 	}


 	public AuthController(AuthenticationManager authenticationManager, TokenUtils tokenUtils, UserDetailsService userDetailsService) {

 		super ();

 		this.authenticationManager = authenticationManager;
 		this.tokenUtils = tokenUtils;
 		this.userDetailsService = userDetailsService;
 	}


 	@Autowired
 	public void setUserDetailsService (UserDetailsService userDetailsService) {

 		this.userDetailsService = userDetailsService;
 	}


 	@Autowired
 	public void setTokenUtils (TokenUtils tokenUtils) {

 		// Set the value.
 		this.tokenUtils = tokenUtils;
 	}


 	@Autowired
 	public void setAuthenticationManager (AuthenticationManager authenticationManager) {

 		this.authenticationManager = authenticationManager;
 	}



    @RequestMapping (method = RequestMethod.POST, produces={MediaType.APPLICATION_JSON_VALUE},
            									  consumes={MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<?> authenticationRequest (@RequestBody AuthenticationRequest authenticationRequest, Device device) throws AuthenticationException {


    	logger.info (String.format ("Authenticating user %s", authenticationRequest.getUsername ()));
    	Authentication authentication = this.authenticationManager.authenticate (

    			new UsernamePasswordAuthenticationToken (authenticationRequest.getUsername (),
                                                         authenticationRequest.getPassword())
        );

    	logger.info (String.format ("Set security context for  %s", authenticationRequest.getUsername ()));
    	SecurityContextHolder.getContext ().setAuthentication (authentication);


    	logger.debug (String.format ("Reload password post-authentication so we can generate token to %s", authenticationRequest.getUsername ()));
    	UserDetails userDetails = this.userDetailsService.loadUserByUsername (authenticationRequest.getUsername ());

    	logger.info (String.format ("Building token to %s", authenticationRequest.getUsername ()));
    	String token = this.tokenUtils.generateToken(userDetails, device);
    	logger.debug (String.format ("Token built to %s", token));


        return ResponseEntity.ok (new AuthenticationResponse(token));
    }
}