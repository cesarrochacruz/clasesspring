
package com.educacionit.java.spring.mongodb.rest.controller.rest;


import java.util.List;


import com.educacionit.java.spring.mongodb.rest.model.security.UserModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;


import org.springframework.security.core.context.SecurityContextHolder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.educacionit.java.spring.mongodb.rest.service.ISecurityService;



@RestController
@RequestMapping ("${app.route.security}")
public class SecurityController {

    private ISecurityService securityService;


	private static final Logger logger = LoggerFactory.getLogger (SecurityController.class);
    
    

 	public SecurityController () {

 		super ();
 	}
 	

 	public SecurityController(ISecurityService securityService) {


 		super ();

 		this.securityService = securityService;
 	}
 	
 	

    @Autowired
    public void setSecurityService (ISecurityService securityService) {

        this.securityService = securityService;
    }
    
    

    @RequestMapping (value = "${app.route.security.user}", method = RequestMethod.GET,
                                                           produces={MediaType.APPLICATION_JSON_VALUE})
    @PreAuthorize("@securityService.hasProtectedAccess ()")
    public ResponseEntity<?> getUser () {

        logger.debug (String.format ("SEARCH EXECUTED By %s", SecurityContextHolder.getContext ().getAuthentication ().getName ()));

        logger.debug (String.format ("Finding all users "));
        List<UserModel> list = this.securityService.findAllUsers ();
        logger.debug (String.format ("All users found (%d) ", list.size ()));

        if (list == null || list.size () == 0) {
            return new ResponseEntity<> (HttpStatus.NOT_FOUND);
        } else {
            return ResponseEntity.ok (list);
        }
    }
}