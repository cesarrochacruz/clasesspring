

package com.educacionit.java.spring.mongodb.rest.model.security;



import java.util.Collection;
import java.time.LocalDateTime;


import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;


import com.fasterxml.jackson.annotation.JsonIgnore;

public class UserModel implements UserDetails {
    
	

	private String id;
	

    private String username;
    

    private String password;
    

    private String email;
    

    private LocalDateTime lastPasswordReset;
    

    private Collection<? extends GrantedAuthority> authorities;
    

    private Boolean accountNonExpired = true;
    

    private Boolean  accountNonLocked = true;
    

    private Boolean credentialsNonExpired = true;
    

    private Boolean enabled = true;
    
    

	private static final long serialVersionUID = 1983562674858523l;
	
	


    public UserModel () {
    

    	super ();
    }


    public UserModel (String id, String username, String password,
    		          String email, LocalDateTime lastPasswordReset, Collection<? extends GrantedAuthority> authorities) {
    	

    	super ();
    	

        this.id = id;
        this.username = username;
        this.password = password;
        this.email = email;
        this.lastPasswordReset = lastPasswordReset;
        this.authorities = authorities;
    }
    

    public String getId () {
    	

        return this.id;
    }


    public void setId (String id) {
    	

        this.id = id;
    }

    public String getUsername () {
    	

        return this.username;
    }

    public void setUsername (String username) {
    	

        this.username = username;
    }


    @JsonIgnore
    public String getPassword () {
    	

        return this.password;
    }


    public void setPassword (String password) {
    	

        this.password = password;
    }

    public String getEmail () {
    	

        return this.email;
    }


    public void setEmail (String email) {
    	

        this.email = email;
    }

    @JsonIgnore
    public LocalDateTime getLastPasswordReset () {
    	
    	// Return the value.
        return this.lastPasswordReset;
    }


    public void setLastPasswordReset (LocalDateTime lastPasswordReset) {
    	

        this.lastPasswordReset = lastPasswordReset;
    }


    @Override
    public Collection<? extends GrantedAuthority> getAuthorities () {
    	

        return this.authorities;
    }

    public void setAuthorities (Collection<? extends GrantedAuthority> authorities) {
    	

        this.authorities = authorities;
    }


    @JsonIgnore
    public Boolean getAccountNonExpired () {
        
    	// Return the value.
    	return this.accountNonExpired;
    }

    public void setAccountNonExpired (Boolean accountNonExpired) {
        

    	this.accountNonExpired = accountNonExpired;
    }


    @Override
    public boolean isAccountNonExpired () {
        

    	return this.getAccountNonExpired ();
    }


    @JsonIgnore
    public Boolean getAccountNonLocked () {
        

    	return this.accountNonLocked;
    }

    public void setAccountNonLocked (Boolean accountNonLocked) {
        

    	this.accountNonLocked = accountNonLocked;
    }

    @Override
    public boolean isAccountNonLocked () {
        

    	return this.getAccountNonLocked ();
    }


    @JsonIgnore
    public Boolean getCredentialsNonExpired () {
        

    	return this.credentialsNonExpired;
    }


    public void setCredentialsNonExpired (Boolean credentialsNonExpired) {
        

    	this.credentialsNonExpired = credentialsNonExpired;
    }


    @Override
    public boolean isCredentialsNonExpired () {
        

    	return this.getCredentialsNonExpired ();
    }

    @JsonIgnore
    public Boolean getEnabled () {
        
    	// Return the value.
    	return this.enabled;
    }

    public void setEnabled (Boolean enabled) {
        

    	this.enabled = enabled;
    }


    @Override
    public boolean isEnabled () {
        

    	return this.getEnabled();
    }
    

 	@Override
 	public String toString () {
 		

 		return String.format ("User Model '%s'", this.username != null ? this.username : "");
 	}
}