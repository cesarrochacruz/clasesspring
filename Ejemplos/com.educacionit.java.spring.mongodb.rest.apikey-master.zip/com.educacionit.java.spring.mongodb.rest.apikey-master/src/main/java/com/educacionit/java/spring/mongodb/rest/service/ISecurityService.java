

package com.educacionit.java.spring.mongodb.rest.service;



import com.educacionit.java.spring.mongodb.rest.model.security.UserModel;

import java.util.List;




public interface ISecurityService {


    Boolean hasProtectedAccess ();

    List<UserModel> findAllUsers ();
}