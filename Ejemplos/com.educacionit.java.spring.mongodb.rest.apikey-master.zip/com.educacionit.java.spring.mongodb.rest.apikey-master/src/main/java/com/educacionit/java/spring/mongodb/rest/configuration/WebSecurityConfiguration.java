

package com.educacionit.java.spring.mongodb.rest.configuration;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.educacionit.java.spring.mongodb.rest.security.AuthenticationTokenFilter;
import com.educacionit.java.spring.mongodb.rest.security.EntryPointUnauthorizedHandler;
import com.educacionit.java.spring.mongodb.rest.service.ISecurityService;

import javax.annotation.Resource;


@Configuration
@EnableWebSecurity
@ComponentScan ({"com.educacionit.java.spring.mongodb.rest.service.impl",
                 "com.educacionit.java.spring.mongodb.rest.domain.entity"})
@EnableGlobalMethodSecurity (prePostEnabled = true)
public class WebSecurityConfiguration extends WebSecurityConfigurerAdapter {
	
	
    // Private class fields declarations.
    private EntryPointUnauthorizedHandler unauthorizedHandler;
    
    private UserDetailsService userDetailsService;

    private ISecurityService securityService;
    

    public WebSecurityConfiguration () {
    	
    	super ();
    }
    

    public WebSecurityConfiguration (EntryPointUnauthorizedHandler unauthorizedHandler, UserDetailsService userDetailsService,
    		                         ISecurityService securityService) {
    	
    	// Call to super class.
    	super ();
    	

    	this.unauthorizedHandler = unauthorizedHandler;
    	this.userDetailsService  = userDetailsService;
    	this.securityService     = securityService;
    }
    
    

    @Override
    protected void configure (HttpSecurity httpSecurity) throws Exception {
    	
        httpSecurity
            .csrf ()
            .disable ()
            .exceptionHandling ()
            .authenticationEntryPoint(this.unauthorizedHandler)
            .and ()
                .sessionManagement ()
                .sessionCreationPolicy (SessionCreationPolicy.STATELESS)
            .and ()
                .authorizeRequests ()
                .antMatchers (HttpMethod.OPTIONS, "/**").permitAll ()
                .antMatchers ("/auth/**").permitAll ()
                .anyRequest ().authenticated ();


          httpSecurity.addFilterBefore (authenticationTokenFilterBean(), UsernamePasswordAuthenticationFilter.class);
    }

    @Override
    public void configure(WebSecurity web) throws Exception {

        web.ignoring().antMatchers("/v2/api-docs", "/configuration/ui", "/swagger-resources/**", "/configuration/**", "/swagger-ui.html", "/webjars/**");
    }
         

    @Autowired
    public void setUnauthorizedHandler (EntryPointUnauthorizedHandler unauthorizedHandler) {
    	
    	this.unauthorizedHandler = unauthorizedHandler;
    }
    
    @Resource
    public void setUserDetailsService (UserDetailsService userDetailsService) {
    	
    	this.userDetailsService = userDetailsService;
    }

    @Autowired
    public void setSecurityService (ISecurityService securityService) {
    	
    	this.securityService = securityService;
    }
    

    @Autowired
    public void configureAuthentication (AuthenticationManagerBuilder authenticationManagerBuilder) throws Exception {
    
    	authenticationManagerBuilder.userDetailsService (this.userDetailsService).passwordEncoder(passwordEncoder ());
    }

    @Bean
    public PasswordEncoder passwordEncoder () {
        
    	return new BCryptPasswordEncoder ();
    }

    @Bean
    @Override
    public AuthenticationManager authenticationManagerBean () throws Exception {
        
    	return super.authenticationManagerBean ();
    }

    @Bean
    public AuthenticationTokenFilter authenticationTokenFilterBean () throws Exception {
        
    	AuthenticationTokenFilter authenticationTokenFilter = new AuthenticationTokenFilter ();
        authenticationTokenFilter.setAuthenticationManager (authenticationManagerBean ());
        return authenticationTokenFilter;
    }

    @Bean
    public ISecurityService securityService () {
    
    	return this.securityService;
    }
}