

package com.educacionit.java.spring.mongodb.rest.repository.mongodb;



import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;


import com.educacionit.java.spring.mongodb.rest.domain.entity.UserEntity;



public interface IUserRepository extends MongoRepository<UserEntity, String> {


    UserEntity findByUserName (String username);


	List<UserEntity> findByUserNameLike (String username);
}