
package com.educacionit.java.spring.mongodb.rest.configuration;


import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.educacionit.java.spring.mongodb.rest.controller.rest.SecurityController;


@Component
public class CorsFilter implements Filter {


    private String tokenHeader = null;


    private static final Logger logger = LoggerFactory.getLogger (SecurityController.class);
    

    public CorsFilter () {

    	super ();
    }
    

    public CorsFilter (String tokenHeader) {
    	
    	// Call to super class.
    	super ();
    }
    

    @Value ("${api.security.token.header}")
    public void setTokenHeader (String tokenHeader) {
    	
    	// Set the value.
    	this.tokenHeader = tokenHeader;
    }

	@Override
	public void destroy () {
		
		// Method setup.
		logger.debug ("Destroying Cors Filters...");
	}

	@Override
	public void doFilter (ServletRequest req, ServletResponse res, FilterChain fil) throws IOException, ServletException {
		
		// Method setup.
		logger.debug ("Ading CORS headers...");
		HttpServletResponse response = (HttpServletResponse) res;
	    response.setHeader ("Access-Control-Allow-Origin", "*");
	    response.setHeader ("Access-Control-Allow-Methods", "POST, GET, PUT, OPTIONS, DELETE");
	    response.setHeader ("Access-Control-Max-Age", "3600");
	    response.setHeader ("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, " + tokenHeader);
	    logger.debug ("CORS headers added...");
	    fil.doFilter (req, res);
	}

	@Override
	public void init (FilterConfig config) throws ServletException {
		
		// Method setup.
		logger.debug ("Initializing Cors Filters...");
	}
}