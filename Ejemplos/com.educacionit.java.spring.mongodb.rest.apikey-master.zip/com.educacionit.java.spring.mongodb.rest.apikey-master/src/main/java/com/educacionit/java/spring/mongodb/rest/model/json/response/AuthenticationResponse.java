

package com.educacionit.java.spring.mongodb.rest.model.json.response;



public class AuthenticationResponse {

	
	// Private instance fields declarations.
	// Token
	private String token = null;

	
	// Public constructor declarations.
    /**
     * 
     *  <p>Constructor without parameters.
     * */
	public AuthenticationResponse () {
		
		// Call to super class.
		super ();
	}
    
	/**
     * 
     *  <p>Constructor with parameters.
     *  
     *  @param token token.
     * */
	public AuthenticationResponse (String token) {
		
		// Call to super class.
		super ();
		this.token = token;
	}
    
	
	// Public instance methode declarations.
	/**
	 * 
	 *  <p>Method that return the token.
	 *  
	 *  @return Return the token.
	 */
	public String getToken () {
		
		// Return the value.
		return this.token;
	}

	/**
	 * 
	 *  <p>Method that set the token.
	 *  
	 *  @param token the token.
	 */
	public void setToken (String token) {
		
		// Set the value.
		this.token = token;
	}

	
	// Public instance method declarations extended of java.lang.Object.
	 /* (non-Javadoc)
	  * @see java.lang.Object#toString ()
	  */
	 @Override
	 public String toString () {
	 		
	 	// Return the value
	 	return String.format ("Token '%s'", this.token);
	 }
}