

package com.educacionit.java.spring.mongodb.rest.security;



import java.io.IOException;


import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;



public class AuthenticationTokenFilter extends UsernamePasswordAuthenticationFilter {


    private String tokenHeader;


    private TokenUtils tokenUtils = null;


    private UserDetailsService userDetailsService = null;

    private static final Logger logger = LoggerFactory.getLogger (AuthenticationTokenFilter.class);
    

    public AuthenticationTokenFilter () {

    	super ();
    }
    

    public AuthenticationTokenFilter (TokenUtils tokenUtils, String tokenHeader, UserDetailsService userDetailsService) {
    	

    	super ();
    	

    	this.tokenUtils  = tokenUtils;
    	this.tokenHeader = tokenHeader;
    	this.userDetailsService = userDetailsService;
    }

    @Autowired
    public void setTokenUtils (TokenUtils tokenUtils) {
    	
    	// Set the value.
    	this.tokenUtils = tokenUtils;
    }
    

    @Value("${api.security.token.header}")
    public void setTokenHeader (String tokenHeader) {
    	

    	this.tokenHeader = tokenHeader;
    }
    

    @Autowired
    public void setUserDetailsService (UserDetailsService userDetailsService) {
    	

    	this.userDetailsService = userDetailsService;
    }
    
    

	@Override
	public void doFilter (ServletRequest req, ServletResponse res, FilterChain fil) throws IOException, ServletException {
	    
		logger.debug ("Getting user details...");
		HttpServletRequest httpRequest = (HttpServletRequest) req;
	    final String authToken = httpRequest.getHeader (this.tokenHeader);
	    final String  username = this.tokenUtils.getUsernameFromToken (authToken);

	    
	    logger.debug ("Checking userdetails...");
	    if (username != null && SecurityContextHolder.getContext().getAuthentication () == null) {
	        
	    	logger.debug (String.format ("Loading user details for '%s'", username));
	    	UserDetails userDetails = this.userDetailsService.loadUserByUsername (username);
	    	
	    	logger.debug (String.format ("RU [Web API Security] :: validating token '%s'", authToken));
	        if (this.tokenUtils.validateToken (authToken, userDetails)) {
	            
	        	UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken (userDetails, null, userDetails.getAuthorities ());
	            authentication.setDetails (new WebAuthenticationDetailsSource().buildDetails(httpRequest));
	            SecurityContextHolder.getContext().setAuthentication (authentication);
	        }
	    }

	    
	    logger.debug ("Calling the next filter.");
	    fil.doFilter (req, res);
	}
}