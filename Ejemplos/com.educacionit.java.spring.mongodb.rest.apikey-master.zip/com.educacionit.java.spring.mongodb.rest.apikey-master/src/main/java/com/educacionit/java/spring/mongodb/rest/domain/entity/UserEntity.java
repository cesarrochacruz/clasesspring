

package com.educacionit.java.spring.mongodb.rest.domain.entity;


import java.io.Serializable;
import java.time.LocalDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document (collection = "user")
public class UserEntity implements Serializable {

	// Id.
	@Id  
	private String id = null;
	

	private String userName = null;
	

	private String password = null;
	

	private String email = null;
	

	private LocalDateTime lastPasswordReset = null;
	

	private String authorities = null;
	

	private LocalDateTime createdAt = null;


	private LocalDateTime updatedAt = null;
	    

	private Integer enabled = 0;
	
	

	public UserEntity () {
		

		super ();
	}
	

	public UserEntity (String id, String userName, String password,
			           String email, LocalDateTime lastPasswordReset, String authorities,
                       LocalDateTime createdAt, LocalDateTime updatedAt, Integer enabled) {
		

		super ();
		

		this.id       = id;
		this.userName = userName;
		this.password = password;
		this.email    = email;
		this.lastPasswordReset = lastPasswordReset;
		this.authorities = authorities;
		this.createdAt   = createdAt;
		this.updatedAt   = updatedAt;
		this.enabled     = enabled;
	}

	

	public String getId () {


		return this.id;
	}
	

	public void setId (String id) {
		

		this.id = id;
	}
	

	public String getUserName () {
		

		return this.userName;
	}

	public void setUserName (String userName) {
		

		this.userName = userName;
	}
	

	public String getPassword () {
		

		return this.password;
	}
	

	public void setPassword (String password) {
		

		this.password = password;
	}
	

	public String getEmail () {
		

		return this.email;
	}

	public void setEmail (String email) {
		

		this.email = email;
	}
	

	public LocalDateTime getLastPasswordReset () {
		

		return this.lastPasswordReset;
	}
	

	public void setLastPasswordReset (LocalDateTime lastPasswordReset) {
		

		this.lastPasswordReset = lastPasswordReset;
	}

	public String getAuthorities () {
		

		return this.authorities;
	}
	

	public void setAuthorities (String authorities) {
		

		this.authorities = authorities;
	}

	public LocalDateTime getCreatedAt () {
		

		return this.createdAt;
	}


	public void setCreatedAt (LocalDateTime createdAt) {
		

		this.createdAt = createdAt;
	}
	

	public LocalDateTime getUpdatedAt () {
		

		return this.updatedAt;
	}


	public void setUpdatedAt (LocalDateTime updatedAt) {
		

		this.updatedAt = updatedAt;
	}


	public Integer getEnabled () {
		

		return this.enabled;
	}


	public void setEnabled (Integer enabled) {
		

		this.enabled = enabled;
	}
	

	@Override
	public int hashCode () {
		
		// Return the value.
		int hash = 0;  
        hash += (this.getId () != null ? this.getId ().hashCode () : 0);  
  
        // Rturn the new value.
        return hash;
	}


	@Override
	public boolean equals (Object object) {
		
		// Return the value.
		if (this == object)  {
			return true;
		}
              
        if (object == null) {
        	return false;
        }  
              
        if (getClass () != object.getClass ()) {
        	return false;
        }  
              

        UserEntity other = (UserEntity) object;  
        if (this.getId () != other.getId () && (this.getId () == null || !this.id.equals (other.getId ()))) {  
            return false;  
        }  
        

        return true; 
	}


	@Override
	public String toString () {
		
		// Return the value
		return String.format ("User Entity '%s'", this.userName != null ? this.userName : "");
	}
}