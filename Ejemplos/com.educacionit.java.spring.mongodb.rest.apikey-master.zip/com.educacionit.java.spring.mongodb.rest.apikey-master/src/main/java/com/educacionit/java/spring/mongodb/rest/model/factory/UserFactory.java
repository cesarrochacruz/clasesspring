

package com.educacionit.java.spring.mongodb.rest.model.factory;



import java.util.Collection;


import com.educacionit.java.spring.mongodb.rest.domain.entity.UserEntity;
import com.educacionit.java.spring.mongodb.rest.model.security.UserModel;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;




public class UserFactory {
	

	private UserFactory () {
		

		super ();
	}
	

    public static UserModel create (UserEntity userEntity) {
        

    	Collection<? extends GrantedAuthority> authorities = null;
    	
    	
    	try {
            

    		authorities = AuthorityUtils.commaSeparatedStringToAuthorityList (userEntity.getAuthorities ());
        } catch (Exception e) {

        	authorities = null;
        }
    	
    	

        return new UserModel (userEntity.getId (),
                              userEntity.getUserName (),
                              userEntity.getPassword (),
                              userEntity.getEmail (),
                              userEntity.getLastPasswordReset (),
                              authorities);
    }
}