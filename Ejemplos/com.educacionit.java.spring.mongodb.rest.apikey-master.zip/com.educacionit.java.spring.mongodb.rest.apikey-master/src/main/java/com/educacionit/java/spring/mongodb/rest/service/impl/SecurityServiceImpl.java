

package com.educacionit.java.spring.mongodb.rest.service.impl;



import java.util.*;
import java.util.stream.Collectors;


import com.educacionit.java.spring.mongodb.rest.model.factory.UserFactory;
import com.educacionit.java.spring.mongodb.rest.model.security.UserModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import com.educacionit.java.spring.mongodb.rest.repository.mongodb.IUserRepository;
import com.educacionit.java.spring.mongodb.rest.service.ISecurityService;



@Service ("securityServiceBean")
public class SecurityServiceImpl implements ISecurityService {



    private IUserRepository repository;


    private static final Logger logger = LoggerFactory.getLogger (SecurityServiceImpl.class);
    

	public SecurityServiceImpl () {
		

		super ();
	}


    @Autowired
    public void setAccountRepository (IUserRepository repository) {


        this.repository = repository;
    }


	@Override
	public Boolean hasProtectedAccess () {
		
		// Checking authorities.
		final Collection<? extends GrantedAuthority> authorities = SecurityContextHolder.getContext ().getAuthentication ().getAuthorities ();
		logger.debug (String.format ("Checking authorities for '%s'", authorities.toString ()));
		return (authorities.contains (new SimpleGrantedAuthority ("ADMIN")));
	}

	@Override
	public List<UserModel> findAllUsers () {

        // Finding users.
        logger.debug (String.format ("Finding all users"));

        // Get all users.
        List<UserModel> list = this.repository.findAll ().
                                               stream ().map (UserFactory::create).
                                               collect (Collectors.toList ());

        // Return the value.
        logger.debug (String.format ("All users found (%d)", list.size ()));
        return list;
	}
}