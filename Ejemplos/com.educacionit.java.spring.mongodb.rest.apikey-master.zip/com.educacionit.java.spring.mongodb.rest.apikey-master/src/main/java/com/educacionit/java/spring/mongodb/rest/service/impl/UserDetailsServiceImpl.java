

package com.educacionit.java.spring.mongodb.rest.service.impl;


import com.educacionit.java.spring.mongodb.rest.domain.entity.UserEntity;
import com.educacionit.java.spring.mongodb.rest.model.factory.UserFactory;
import com.educacionit.java.spring.mongodb.rest.repository.mongodb.IUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@Service ("userDetailsServiceBean")
public class UserDetailsServiceImpl implements UserDetailsService {
	

    private IUserRepository userRepository = null;


	private static final Logger logger = LoggerFactory.getLogger (UserDetailsServiceImpl.class);
  
	

	public UserDetailsServiceImpl () {
		

		super ();
	}

	public UserDetailsServiceImpl (IUserRepository userRepository) {
		

		super ();
		

		this.userRepository = userRepository;
	}
	

	@Autowired
	public void setUserRepository (IUserRepository userRepository) {
		

		this.userRepository = userRepository;
	}
	

	@Override
	public UserDetails loadUserByUsername (final String username) throws UsernameNotFoundException {
		

        UserDetails user;
		try {

			logger.debug (String.format ("Finding user ['%s']", username));
			final UserEntity userEntity = this.userRepository.findByUserName (username);


			logger.debug (String.format ("Validating user ['%s']", username));
			if (userEntity == null) {

				logger.error (String.format ("User ['%s'] not found.", username));
				throw new UsernameNotFoundException (String.format("User  not found with username '%s'.", username));

			} else {

				logger.debug (String.format ("Creating new user bean model ['%s']", username));
				user = UserFactory.create (userEntity);
			}

		} catch (Exception e) {

		    String s = String.format ("Problems loading user %s", username);
		    throw new SecurityException (s);
		}


		return user;
	}
}