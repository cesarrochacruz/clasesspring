{
        "userName" : "admin",
        "password" : "$2a$10$PUpnDPC2ivmEPArrYAoqVOo4V.gIVKsSwnQR6MFkjVzbSlqp28LNO",
        "email" : "admin@gmail.com",
        "lastPasswordReset" : null,
        "authorities" : "ADMIN",
        "createdAt" : null,
        "updatedAt" : null,
        "enabled" : 0
}