# com.educacionit.hibernate.startup
Learning Hibernate (Beginners)
