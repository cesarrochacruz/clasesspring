
package com.educacionit.hibernate.test;


import java.util.List;

import com.educacionit.hibernate.Person;
import org.hibernate.*;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.criterion.Restrictions;

import org.apache.log4j.Logger;

import org.junit.jupiter.api.*;


public class HibernateTest {


    private static SessionFactory factory;
    private static ServiceRegistry serviceRegistry;

    private static final Logger logger = Logger.getLogger (HibernateTest.class);


    public HibernateTest () {

        super ();
    }


    @BeforeAll
    public static void setup () {

        Configuration config = new Configuration ();
        config.configure ();
        config.addAnnotatedClass (Person.class);
        config.addResource ("Person.hbm.xml");

        serviceRegistry = new StandardServiceRegistryBuilder ().applySettings (config.getProperties ()).build ();
        factory = config.buildSessionFactory (serviceRegistry);
    }

    @AfterAll
    public static void destroy () {

        factory.close ();
        serviceRegistry = null;
    }

    @Test
    @DisplayName ("Creating Persons")
    public void m1 () {

        logger.info ("Executing test...");
        Session session = factory.openSession ();
        Transaction tx = null;

        try {

            tx = session.beginTransaction ();

            Person[] persons = new Person[]{ new Person ("Homer Simpson", "EEUU"),
                                             new Person ("Marge Simpson", "EEUU"),
                                             new Person ("Bart Simpson", "EEUU"),
                                             new Person ("Lisa Simpson", "EEUU"),
                                             new Person ("Maggie Simpson", "EEUU")};

            Person[] players  = new Person[]{ new Person ("Homer Simpson", "EEUU"),
                    new Person ("Lionel Messi", "Argentina"),
                    new Person ("Cristiano Ronaldo", "Portugal"),
                    new Person ("Zlatan Ibrahimovic", "Suecia")};

            for (Person p: persons) {
                session.save (p);
            }

            for (Person p: players) {
                session.save (p);
            }

            logger.debug ("Executing insert batch persons.");
            tx.commit();

            Assertions.assertTrue (persons[0].getId () > 0, "Problems creating persons.");

        } catch (HibernateException ex) {

            logger.error (ex.getMessage ());
            tx.rollback ();
            Assertions.assertFalse (Boolean.TRUE, "Problems executing the test.");

        } finally { session.close(); }
    }

    @Test
    @DisplayName ("Finding all Persons")
    public void m2 () {

        logger.info ("Executing test...");
        Session sesn = factory.openSession ();
        Transaction tx;
        List<Person> persons;

        try {

            logger.debug ("Executing select All persons.");
            tx = sesn.beginTransaction ();
            persons = (List)sesn.createQuery("From Person").list ();
            tx.commit ();

            Assertions.assertFalse (persons.isEmpty (), "There are not Persons found!!!");

        } catch(HibernateException e) {

            logger.error (e.getMessage ());
            Assertions.assertFalse (Boolean.TRUE, "Problems executing the test.");

        } finally { sesn.close(); }
    }

    @Test
    @DisplayName ("Update a Person")
    public void m3 () {

        logger.info ("Executing test...");
        Session sesn = factory.openSession ();
        Transaction tx;
        Person person;

        try {

            logger.debug ("Executing select first person.");
            tx = sesn.beginTransaction ();
            person = (Person) sesn.createCriteria (Person.class).add (Restrictions.ilike ("country", "argentina")).uniqueResult ();

            Assertions.assertNotNull (person, "There is not Person found!!!");

            logger.debug ("Executing updating first person.");
            person.setName (person.getName ().toUpperCase ());
            tx.commit ();

        } catch(HibernateException e) {

            logger.error (e.getMessage ());
            Assertions.assertFalse (Boolean.TRUE, "Problems executing the test.");

        } finally { sesn.close(); }
    }

    @Test
    @DisplayName ("Deleting all Persons")
    public void m4 () {

        logger.info ("Executing test...");
        Session sesn = factory.openSession ();
        Transaction tx;
        List<Person> persons;

        try {

            logger.debug ("Executing select All persons.");
            tx = sesn.beginTransaction ();
            persons = (List)sesn.createQuery("From Person").list ();
            Assertions.assertFalse (persons.isEmpty (), "There are not Persons found!!!");

            persons.forEach (e -> sesn.delete (e));
            tx.commit ();

            persons = (List)sesn.createQuery("From Person").list ();
            Assertions.assertTrue (persons.isEmpty (), "There are Persons found!!!");

        } catch(HibernateException e) {

            logger.error (e.getMessage ());
            Assertions.assertFalse (Boolean.TRUE, "Problems executing the test.");

        } finally { sesn.close(); }
    }
}