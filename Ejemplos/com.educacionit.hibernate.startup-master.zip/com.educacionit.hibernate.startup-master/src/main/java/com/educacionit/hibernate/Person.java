
package com.educacionit.hibernate;


public class Person {

    private int id;
    private String name;
    private String country;

    public Person () {

        super ();
    }

    public Person (String name, String country) {

        super ();

        this.name    = name;
        this.country = country;
    }


    public int getId () {

        return this.id;
    }

    public void setId (int id) {

        this.id = id;
    }

    public String getName () {

        return this.name;
    }

    public void setName (String name) {

        this.name = name;
    }

    public String getCountry () {

        return this.country;
    }

    public void setCountry (String country) {

        this.country = country;
    }
}