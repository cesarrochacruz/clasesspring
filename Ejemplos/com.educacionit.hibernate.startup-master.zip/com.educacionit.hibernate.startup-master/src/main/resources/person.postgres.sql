CREATE SEQUENCE public."SQ_PERSON"
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE public."SQ_PERSON"
    OWNER TO postgres;



-- Table: public."PERSON"

-- DROP TABLE public."PERSON";

CREATE TABLE public."PERSON"
(
    "ID" integer NOT NULL,
    "NAME" character varying(56) COLLATE pg_catalog."default" NOT NULL,
    "COUNTRY" character varying(128) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT "PERSON_pkey" PRIMARY KEY ("ID")
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public."PERSON"
    OWNER to postgres;