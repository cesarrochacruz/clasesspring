# com.educacionit.hibernate.beginners
Learning Hibernate (Beginners)
