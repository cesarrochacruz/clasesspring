
package com.educacionit.spring.beginning.class05.users.dao;


import com.educacionit.spring.beginning.class05.users.model.UserAttempts;


public interface UserDetailsDao {

	void updateFailAttempts(String username);

	void resetFailAttempts(String username);
	
	UserAttempts getUserAttempts(String username);
}