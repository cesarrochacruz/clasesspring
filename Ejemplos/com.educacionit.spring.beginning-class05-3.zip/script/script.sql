
CREATE  TABLE users (
  username VARCHAR(45) NOT NULL ,
  password VARCHAR(45) NOT NULL ,
  enabled INTEGER NOT NULL DEFAULT 1 ,
  accountNonExpired INTEGER NOT NULL DEFAULT 1 ,
  accountNonLocked INTEGER NOT NULL DEFAULT 1 ,
  credentialsNonExpired INTEGER NOT NULL DEFAULT 1,
  PRIMARY KEY (username));

CREATE TABLE user_roles (
  user_role_id serial NOT NULL,
  username varchar(45) NOT NULL,
  role varchar(45) NOT NULL,
  PRIMARY KEY (user_role_id),
  CONSTRAINT fk_username FOREIGN KEY (username) REFERENCES users (username));

CREATE TABLE user_attempts (
  id serial NOT NULL,
  username varchar(45) NOT NULL,
  attempts integer NOT NULL,
  lastModified timestamp,
  PRIMARY KEY (id)
);
  
INSERT INTO users(username,password,enabled)
VALUES ('rpena','123456', 1);

INSERT INTO users(username,password,enabled)
VALUES ('admin','123456', 1);

INSERT INTO user_roles (username, role)
VALUES ('rpena', 'ROLE_USER');

select * from user_roles

INSERT INTO user_roles (username, role)
VALUES ('admin', 'ROLE_ADMIN');
    