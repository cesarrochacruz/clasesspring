

package com.educacionit.java.spring.data.jpa.rest.excerpt;



import com.educacionit.java.spring.data.jpa.rest.entities.CityEntity;
import com.educacionit.java.spring.data.jpa.rest.entities.ProvinceEntity;
import org.springframework.data.rest.core.config.Projection;


@Projection (name="CityExcerpt", types = CityEntity.class)
public interface CityExcerpt { 
	
	
	Integer getId ();
	
	
	String getName ();
	
	
	ProvinceEntity getProvince ();
}