

package com.educacionit.java.spring.data.jpa.rest.repositories;



import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.educacionit.java.spring.data.jpa.rest.entities.CountryEntity;
import com.educacionit.java.spring.data.jpa.rest.excerpt.CountryExcerpt;





@RepositoryRestResource (itemResourceRel="country", collectionResourceRel = "country", path = "country", 
                         excerptProjection = CountryExcerpt.class)
public interface ICountryRepositoryRest extends CrudRepository<CountryEntity, Integer> {

	

}