

package com.educacionit.java.spring.data.jpa.rest.excerpt;



import com.educacionit.java.spring.data.jpa.rest.entities.ProvinceEntity;
import org.springframework.data.rest.core.config.Projection;

import com.educacionit.java.spring.data.jpa.rest.entities.CountryEntity;


@Projection (name="ProvinceExcerpt", types = ProvinceEntity.class)
public interface ProvinceExcerpt { 
	
	
	
	Integer getId ();
	
	String getName ();
	
	
	CountryEntity getCountry ();
}