

package com.educacionit.java.spring.data.jpa.rest.excerpt;



import org.springframework.data.rest.core.config.Projection;

import com.educacionit.java.spring.data.jpa.rest.entities.CountryEntity;




@Projection (name="CountryExcerpt", types = CountryEntity.class)
public interface CountryExcerpt { 
	
	
	
	Integer getId ();
	
	
	String getCode ();
	
	
	String getName ();
}