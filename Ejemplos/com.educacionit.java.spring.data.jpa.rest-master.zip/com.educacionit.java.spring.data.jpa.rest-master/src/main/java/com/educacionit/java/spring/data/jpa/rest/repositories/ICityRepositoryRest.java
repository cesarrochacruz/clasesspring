

package com.educacionit.java.spring.data.jpa.rest.repositories;



import com.educacionit.java.spring.data.jpa.rest.entities.CityEntity;
import com.educacionit.java.spring.data.jpa.rest.excerpt.CityExcerpt;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;


@RepositoryRestResource (itemResourceRel="city", collectionResourceRel = "city", path = "city",
                         excerptProjection = CityExcerpt.class)
public interface ICityRepositoryRest extends CrudRepository<CityEntity, Integer> {

	

}