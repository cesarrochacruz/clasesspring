# springmvc-startup-teacher-01

## Description

This project is a classic Spring MVC application. This is a Personal web Site.

### How to run the project:


> 1.	Prepare for your email incoming and outgoing addresses.
> 2.	There must be Java 1.8 installed. 
> 3.	Run clean and package maven commands.
> 4.	copy the war make inside tomcat.
> 5.	open a browser and got to http://localhost:8080/spring-pwp/pwp/index.html
