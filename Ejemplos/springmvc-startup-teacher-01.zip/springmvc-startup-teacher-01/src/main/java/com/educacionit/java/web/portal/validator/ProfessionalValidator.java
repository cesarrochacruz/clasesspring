
package com.educacionit.java.web.portal.validator;

import com.educacionit.java.web.portal.model.form.Professional;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

/*
 * This class is used to validate the Professional Page updater
 */
public class ProfessionalValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {

		return Professional.class.equals(clazz);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		// Professional professional = (Professional) obj;
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "position",
				"position.empty");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "company",
				"company.empty");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "years",
				"years.empty");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "location",
				"location.empty");

	}

}
