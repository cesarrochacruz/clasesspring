
package com.educacionit.java.web.portal.controller;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.educacionit.java.web.portal.model.form.Biography;
import com.educacionit.java.web.portal.model.form.Education;
import com.educacionit.java.web.portal.model.form.Personal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.view.RedirectView;


/*
 * This controller calls the Personal Information page
 */
@Controller
@RequestMapping("/pwp/")
public class PersonalController {

	/*
	 * Initializes the Information page
	 */
	@SuppressWarnings("deprecation")
	public Personal initPersonal() {
		Biography bio = new Biography();
		bio.setFirstName("Homer");
		bio.setLastName("Simpson");
		bio.setAge(39);
		bio.setBirthDate(new Date(56, 5, 12));
		bio.setLocation("Springfield");
		bio.setCountry("EEUU");

		List<String> hobbies = new ArrayList<>();
		hobbies.add("Drink Beer");
		hobbies.add("Eat");
		hobbies.add("Sleep");
		List<String> readings = new ArrayList<>();
		readings.add("PlayBoy");
		readings.add("Bets");

		bio.setHobbies(hobbies);
		bio.setReadings(readings);

		Education educ = new Education();
		educ.setEducLevel("None");
		educ.setDegree("No Degree");
		educ.setInstitution("Spring High School");
		educ.setSpecialization("Sleep");
		educ.setYear(1974);

		Personal person = new Personal();
		person.setEducation(educ);
		person.setBiography(bio);

		return person;
	}

	/*
	 * Calls the Personal Information page
	 */
	@RequestMapping(value = "/personal", method = RequestMethod.GET)
	public String getPersonal(Model model) {
		model.addAttribute("person", initPersonal());
		return "personal";
	}

	/*
	 * Calls the content update page for the Personal Information page
	 */
	@RequestMapping(value = "/personal_redirect", method = RequestMethod.GET)
	public RedirectView updatePersonal() {
		return new RedirectView("/spring-pwp/pwp/personal_update.html");
	}

}
