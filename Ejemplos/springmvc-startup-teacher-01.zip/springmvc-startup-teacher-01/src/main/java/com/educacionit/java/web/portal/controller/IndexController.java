
package com.educacionit.java.web.portal.controller;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.educacionit.java.web.portal.model.form.Home;
import com.educacionit.java.web.portal.model.form.PostMessage;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.view.RedirectView;


/*
 * This controller calls the Home Page of PWP.
 */
@Controller
@SessionAttributes("posts")
@RequestMapping("pwp")
public class IndexController {

	/*
	 * Initializes the posts session attribute
	 */
	@ModelAttribute("posts")
	public List<PostMessage> newPosts() {
		return initPost();
	}
     	
	public List<PostMessage> initPost() {
		List<PostMessage> posts = new ArrayList<>();
		PostMessage post = new PostMessage();
		post.setSubject("Welcome!");
		post.setDatePosted(new Date());
		post.setPostedMsg("Hello visitors! Feel free to post on my portal!");
		posts.add(post);
		return posts;
	}

	// Initial values
	public String initQuote() {
		String message = "Dear Lord, the gods have been good to me. As an offering, I present these milk and cookies. If you wish me to eat them instead, please give me no sign whatsoever...thy will be done.";
		return message;
	}

	public String initMessage() {
		String message = "The code of the schoolyard, Marge! The rules that teach a boy to be a man. Let's see. Don't tattle. Always make fun of those different from you. Never say anything, unless you're sure everyone feels exactly the same way you do.";
		return message;
	}

	
    /*
     * Validates the existence of post messages
     */
	public boolean validatePost(PostMessage post) {
		try {
			if (post.getSubject().trim().length() == 0
					|| post.getPostedMsg().trim().length() == 0) {
				return false;
			}
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	/*
	 * Calls the index home page
	 */
	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public String getIndex(Model model,
			@ModelAttribute("posts") List<PostMessage> posts,
			@ModelAttribute("postForm") PostMessage postForm) {
		Home home = new Home();
		home.setMessage(initMessage());
		home.setQuote(initQuote());
		model.addAttribute("home", home);

		// initializes the post-it panel
		if (posts == null)
			posts = newPosts();
		if (validatePost(postForm)) {
			postForm.setDatePosted(new Date());
			posts.add(postForm);
		}
		model.addAttribute("posts", posts);
		return "index";
	}

	/*
	 * Calls the update home page
	 */
	@RequestMapping(value = "/index_redirect", method = RequestMethod.GET)
	public RedirectView updateIndex() {
		return new RedirectView("/spring-pwp/pwp/index_update.html");
	}
	
	
	/*
	 * Calls the default index.html
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public RedirectView getDefault() {
		return new RedirectView("/spring-pwp/pwp/index.html");
	}

}
