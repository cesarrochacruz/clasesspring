
package com.educacionit.java.web.portal.model.form;


public class Personal {

	private Biography biography;
	private Education education;

	public Biography getBiography() {
		return biography;
	}

	public void setBiography(Biography biography) {
		this.biography = biography;
	}

	public Education getEducation() {
		return education;
	}

	public void setEducation(Education education) {
		this.education = education;
	}

}
