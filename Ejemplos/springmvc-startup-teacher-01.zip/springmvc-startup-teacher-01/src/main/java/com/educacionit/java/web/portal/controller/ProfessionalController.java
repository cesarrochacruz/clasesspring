
package com.educacionit.java.web.portal.controller;


import java.util.ArrayList;
import java.util.List;

import com.educacionit.java.web.portal.model.form.Professional;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.view.RedirectView;


/*
 * This controller calls the Professional Informatin page
 */
@Controller
@RequestMapping("/pwp")
public class ProfessionalController {

	@RequestMapping(value = "/professional", method = RequestMethod.GET)
	public String getProfessional(Model model) {
		model.addAttribute("professional", initProfessional());
		return "professional";
	}

	@RequestMapping(value = "/professional_redirect", method = RequestMethod.GET)
	public RedirectView updatePersonal() {
		return new RedirectView("/spring-pwp/pwp/professional_update.html");
	}

	private Professional initProfessional() {
		Professional professional = new Professional();
		professional.setPosition("Nuclear Safety Inspector");
		professional.setCompany("Springfield Nuclear Power Plant");
		professional.setYears(20);
		professional.setLocation("Springfield");

		List<String> prevJobs = new ArrayList<>();
		prevJobs.add("Vague");
		prevJobs.add("Hotdog Seller");

		List<String> skillSets = new ArrayList<>();
		skillSets.add("Sleep");
		skillSets.add("Loaf");

		professional.setPrevJobs(prevJobs);
		professional.setSkillSets(skillSets);

		return professional;
	}
}
