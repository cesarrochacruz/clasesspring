

package com.educacionit.spring.beginning.class04;


import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;


@Component
public class Consumer {


	@JmsListener(destination = "educacionit.queue")
	public void receiveQueue(String text) {
		System.out.println(text);
	}

}
