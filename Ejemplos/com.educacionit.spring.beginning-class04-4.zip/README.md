# com.educacionit.spring.beginning-class04-4
Java Education Project for learn Springframework.



## Introducción
Este demo esta constituido por una aplicacion, llamada "com.educacionit.spring.beginning-class04-4" la cual se encarga de
mostrar un simple productor / consumidor jms, aca demostraremos los siguientes conceptos:

1. El uso de spring boot y jms.
2. El uso de activemq.


## Requerimientos
1. Maven
2. Cualquier IDE de desarrollo con soporte Java y Maven.
3. Apache Activemq (http://activemq.apache.org/)



Ejercicios (Básicos/Intermedio)
==========

La configuración de este proyecto es independiente de cualquier IDE de desarrollo, debido a que el proyecto
fue creado utilizando maven. (http://maven.apache.org)

Así que son libres de utilizar el IDE con el cual se sientan más agusto.


Referencias
===========

1. http://maven.apache.org/
2. http://activemq.apache.org/
2. https://projects.spring.io/spring-framework/